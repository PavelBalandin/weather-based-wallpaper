
## Time Weather Wallpaper
Sample webpage wallpaper project

Sample project for [Lively Wallpaper.](https://github.com/rocksdanister/lively)